/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_musical_library;

/**
 *
 * @author Vitaly
 */
import java.io.*;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.Scanner;
import java.util.Vector;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import de.jeckle.RS2DOM.RS2DOM;
import java.sql.Connection;


public class Java_musical_Library {

    /**
     *
     * @param args
     */
    public static Scanner sc = new Scanner(System.in); // класс для работы с консолью
    public static Connection connect = null;
    //public static CallableStatement callableStatement = null;
    public static void main(String[] args) throws ClassNotFoundException, 
            SQLException, InstantiationException, IllegalAccessException, 
            FileNotFoundException, ParseException 
    {
                
        java.sql.Statement rqst = null; // объект для выполнения SQL запросов
        
        int table_number = 0;    // номер введенной таблицы
        Vector<String> vec_tab = new Vector<String>();
        String temp2 = null;   // временные строковые переменные
        String [] temp3 = null;
        StringBuilder sb = new StringBuilder(); //объект для построения строки
        int menu_select = 0; // переменная = выбранный пункт меню
        int argz;   // входной аргумент для операции INSERT
        int cnt_col = 0; //переменная для вывода содержимого таблицы                               
        ResultSet res; // Класс для хранения результатов SQL запроса
        // Иницализация драйвера
        Class.forName("org.firebirdsql.jdbc.FBDriver").newInstance();
        //Указание пути к БД
        String strPath;
        strPath = "jdbc:firebirdsql://localhost/C:/Users/Vitaly/Desktop/BaseDann/my/HP/D_5.fdb";
        Class.forName("org.firebirdsql.jdbc.FBDriver").newInstance();
        //Подключение к БД
        connect = DriverManager.getConnection(strPath, "SYSDBA", "masterkey");
        if (connect == null) {
            System.err.println("Невозможно подключиться к БД.");}
        //Создание класса для выполнения SQL запросов
        rqst = connect.createStatement();
        System.out.println("Подключение к БД успешно выполнено.");
        // Получение списка таблиц БД
                DatabaseMetaData metaData = connect.getMetaData();
        ResultSet temp=metaData.getTables(temp2, temp2, temp2, temp3);
        while(temp.next())
	{
            temp2=temp.getString(3);
            if(!temp2.contains("$"))
                vec_tab.add(temp2);
        }
        // Меню
        while (menu_select != 6) {
            // вывод меню
            System.out.println("-------------------------------------------");
            System.out.println("|               MUSIC_LIBRARY               |");
            System.out.println("-------------------------------------------");
            System.out.println("Функции:");
            System.out.println("1.Вывод списка всех таблиц");
            System.out.println("2.Добавление записи в таблицу TYPE");
            System.out.println("3.Выполнение хранимой процедуры FIVE_ARTS");
            System.out.println("4.Выполнение любых sql запросов на выборку");
            System.out.println("5.Выход из программы");
             // считывание номера пункта меню
            System.out.println("Выберите пункт меню:");
            try{
                menu_select = Integer.parseInt(sc.nextLine());
            }catch(NumberFormatException e){
                System.err.println("Ошибка! Вводите только цифры.");
                continue;
            }
             if (menu_select > 5)
                System.err.println("Ошибка! Пункт меню с таким номером отсутствует.");
             if (menu_select == 1)
            {               
                System.out.println("Список таблиц:");
                for(int i=1;i<=vec_tab.size();i++)
                {
                    System.out.printf("%d. %s\n",i,vec_tab.elementAt(i-1));
                }
                                System.out.println("Введите номер таблицы для отображения ее содержимого или "
                                        + "\n0 для возврата в основное меню:");
                                try{
                    table_number=Integer.parseInt(sc.nextLine());
                }catch(NumberFormatException e){
                    System.err.println("Ошибка! Номер должен быть числом!");
                    continue;
                }
                if((table_number > vec_tab.size()) || (table_number < 0)){
                    System.err.println("Ошибка! Таблица с таким номером отсутсвует.");
                    continue;
                }
                if(table_number == 0){
                    continue;
                }
                System.out.println();
                //Выполнение SQL запроса
          	    res = rqst.executeQuery("SELECT * from "+ vec_tab.elementAt(table_number-1));                                        
                // Вывод результата
                cnt_col = res.getMetaData().getColumnCount();
                
                // Вывод содержимого таблицы
                // Сначала имена столбцов:
                for(int i = 1; i < cnt_col + 1; i++){
                    System.out.print(res.getMetaData().getColumnName(i)+
                            "  |  ");
                }
                // Затем сами записи в таблице:
                while(res.next())
                {
                    System.out.println();
                    for (int i = 1;i < cnt_col + 1;i++)
                    {
                        
                        
                            Object obj = res.getObject(i);
                            if (obj!=null)
                            {
                                    System.out.print(obj+"   \t   ");

                            }
                    }
                }
                System.out.println();
                                 
                continue;
            } 
            if (menu_select == 2 )
            {
                if(connect == null) {
                    System.err.println("Соединение с БД не установлено.");
                    continue;
                }  
                // ВВОД АРГУМЕНТОВ ДЛЯ ОПЕРАЦИИ INSERT
                System.out.println("Введите ID:");
                try{
                    argz=Integer.parseInt(sc.nextLine());
                   }catch(NumberFormatException e){
                System.err.println("Ошибка! ID не является числом или превышает 9 символов.");
                continue;
                }
                if (argz <= 0)
                {
                    System.err.println("Ошибка! ID не может быть отрицательным или равным нулю.");
                    continue;
                }
                    
                System.out.println("Введите тип альбома:");                                
                String argz2 = sc.nextLine();
                if (argz2.length()>1 || argz2.isEmpty())
                {
                    System.err.println("Ошибка! Название типа не может быть пустым или больше 1 символа.");
                    continue;
                }
                      
                //////////////////
                System.out.println("Введите название альбома:");                                
                String argz22 = sc.nextLine();
                if (argz22.length()>50 || argz22.isEmpty())
                {
                    System.err.println("Ошибка! Название типа не может быть пустым или больше 50 символов.");
                    continue;
                }                
                
                
                /////////////////
                
                try{                             
                    rqst.executeUpdate("insert into TYPE values ('"+argz+"','"+argz2+"','"+argz22+"');");
                    System.out.println("Запись добавлена в таблицу.");
                }catch (SQLException se){
                    System.out.println(se.getMessage());
                }
                    
                continue;
            }
            if (menu_select == 3)
            {
                
                if(connect == null) {
                    System.err.println("Соединение с БД не установлено.");
                    continue;
                }
                System.out.println("Хранимая процедура FIVE_ARTS"
   + " Вывести 5 исполнителей с наилучшим увеличением производительности за заданный период \n");
                
                System.out.println("Введите начало периода:");                                
                String min_date = sc.nextLine();
                System.out.println("Введите конец периода:");                                
                String max_date = sc.nextLine();
                System.out.println(); 
            //Вызываем функцию (которая хранится в БД)
             
            CallableStatement callableStatement = connect.prepareCall(
                    "{call FIVE_ARTS('"+min_date+"','"+max_date+"')} ");
             ResultSet result3 = callableStatement.executeQuery();
             System.out.println("\tART_ID      |\tPERFOMANCE");
             System.out.println("----------------------------");                                      
             while (result3.next()) {
                   System.out.println("\t"+result3.getInt("ART_ID")+"\t\t"+result3.getFloat("PERFOMANCE"));                      
                }
             System.out.println();
                callableStatement.execute();
                System.out.println("\nХранимая процедура FIVE_ARTS выполнена.");
                callableStatement.close();
                continue;  
                          
            }
            
                                if (menu_select == 4)
           {
                System.out.println("\nВведите запрос: \n");
                String new_req = sc.nextLine();
                if (!(new_req.contains("UPDATE")) && !(new_req.contains("update"))
                        && !(new_req.contains("DELETE")) && !(new_req.contains("delete"))
                        && !(new_req.contains("INSERT")) && !(new_req.contains("insert")) )
                        {
                            try{                             
                                res = rqst.executeQuery(new_req);
                                cnt_col = res.getMetaData().getColumnCount();
                            for(int i = 1; i < cnt_col + 1; i++){
                                System.out.print(res.getMetaData().getColumnName(i)+
                                "  |  ");
                            }
                            // Затем сами записи в таблице:
                            while(res.next())
                            {
                                System.out.println();
                                for (int i = 1;i < cnt_col + 1;i++)
                                {
                                    Object obj = res.getObject(i);
                                    if (obj!=null)
                                    {
                                        System.out.print(obj+"   \t   ");

                                    }
                                }
                            }
                            System.out.println();
                            }catch (SQLException se){
                                System.out.println(se.getMessage());
                            }
                            
                        }
                else {
                    System.out.println("Внимание! Введен неверный запрос. "
                            + "Изменение, добавление и удаление записей невозможно.\n");
                    continue;
                }
            }
 if (menu_select == 5)
            {
                    System.out.println("Goodbye");
                    System.exit(0);
            }
        }
        System.exit(0);
    }
}
